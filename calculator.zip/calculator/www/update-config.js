window.AHOS_UPD={repo:'PUT_USER/PUT_REPO'};
