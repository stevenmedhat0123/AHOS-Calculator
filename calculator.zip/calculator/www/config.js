window.AHOS_CFG = { apiKey: 'PUT_API_KEY', projectId: 'PUT_PROJECT_ID' };
