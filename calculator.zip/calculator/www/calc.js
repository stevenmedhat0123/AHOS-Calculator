// Scientific calculator. A normal calculator; the secret code + "=" opens the hidden messenger (first launch asks for the code once)
(()=>{
const $=s=>document.querySelector(s),ls=localStorage;
const H=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode('calc:'+s)))].map(x=>x.toString(16).padStart(2,'0')).join('');
const act=()=>ls.getItem('c_act')=='1',ch=()=>ls.getItem('c_ch')||window.__CH0;
let ex='',ans=0,busy=0,done=0;
const fmt=n=>{if(!isFinite(n))return 'Math ERROR';if(Math.abs(n)<1e-12)return '0';let s=String(+n.toPrecision(11));return s.length>13?n.toExponential(6):s};
const ev=s=>{const T=s.replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').match(/\d*\.?\d+(?:e[+-]?\d+)?|sin\(|cos\(|tan\(|log\(|ln\(|√\(|Ans|π|e|[-+*/^%()]/g)||[];let i=0;
const pk=()=>T[i],st=t=>t&&(/^[\d.]/.test(t)||/\($/.test(t)||t=='π'||t=='e'||t=='Ans');
const E=()=>{let v=Tm();while(pk()=='+'||pk()=='-'){const o=T[i++],r=Tm();v=o=='+'?v+r:v-r}return v};
const Tm=()=>{let v=U();for(;;){const p=pk();if(p=='*'||p=='/'){i++;const r=U();v=p=='*'?v*r:v/r}else if(st(p))v*=U();else break}return v};
const U=()=>{if(pk()=='-'){i++;return -U()}if(pk()=='+'){i++;return U()}return Pw()};
const Pw=()=>{let b=Po();if(pk()=='^'){i++;b=Math.pow(b,U())}return b};
const Po=()=>{let v=Pr();while(pk()=='%'){i++;v/=100}return v};
const Pr=()=>{const t=T[i++];if(t===undefined)throw 0;if(t=='('){const v=E();if(pk()==')')i++;return v}if(t=='π')return Math.PI;if(t=='e')return Math.E;if(t=='Ans')return ans;
 if(/\($/.test(t)){const v=E();if(pk()==')')i++;const r=Math.PI/180;switch(t){case 'sin(':return Math.sin(v*r);case 'cos(':return Math.cos(v*r);case 'tan(':return Math.tan(v*r);case 'log(':return Math.log10(v);case 'ln(':return Math.log(v);case '√(':return Math.sqrt(v)}}
 const n=parseFloat(t);if(isNaN(n))throw 0;return n};
const v=E();if(i<T.length)throw 0;return v};
const show=(main,hist)=>{const r=$('#r');r.textContent=main;r.style.fontSize=String(main).length>11?'28px':String(main).length>8?'36px':'44px';const h=$('#h');h.textContent=hist!==undefined?hist:(act()?ex:'أدخل رمز التفعيل ◂');if(h.scrollLeft!==undefined)h.scrollLeft=1e6};
const draw=()=>show(ex?'':'0',act()?ex:undefined);
const openApp=()=>{if(window.AHOSM)return window.AHOSM.open();if(busy)return;busy=1;const s=document.createElement('script');s.src='app.js';s.onload=()=>{busy=0;window.AHOSM&&window.AHOSM.open()};s.onerror=()=>{busy=0};document.head.appendChild(s)};
const equals=async()=>{
 if(/^\d{3,12}$/.test(ex)&&await H(ex)==ch()){ls.setItem('c_act','1');ex='';show('0','');openApp();return}
 if(!act()){const d=$('.lcd');d.classList.remove('shake');void d.offsetWidth;d.classList.add('shake');ex='';show('0');return}
 if(!ex)return;try{const v=ev(ex);ans=v;show(fmt(v),ex);ex=fmt(v);done=1}catch(e){show('Syntax ERROR',ex);ex='';done=1}};
const INS={sin:'sin(',cos:'cos(',tan:'tan(',log:'log(',ln:'ln(','√':'√(','x²':'^2','^':'^','(':'(',')':')','π':'π',e:'e',Ans:'Ans','%':'%',EXP:'×10^','×':'×','÷':'÷','+':'+','−':'−','.':'.'};
$('#kp').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const k=b.dataset.k;
 if(k=='='){equals();return}
 if(k=='AC'){ex='';done=0;draw();return}
 if(k=='DEL'){ex=ex.replace(/(sin\(|cos\(|tan\(|log\(|ln\(|√\(|Ans|×10\^|.)$/,'');draw();return}
 if(k=='NEG'){ex=ex.length&&ex[0]=='−'?ex.slice(1):'−'+ex;draw();return}
 if(k=='SHIFT'||k=='ALPHA'||k=='PAD'||k=='MODE')return;
 const ins=INS[k]!==undefined?INS[k]:(/^\d$/.test(k)?k:null);if(ins===null)return;
 const isOp=/^[+×÷−^%]|^×10/.test(ins)||ins=='^2';
 if(done&&!isOp)ex='';done=0;
 if(isOp&&!ex&&ins!='−')return;
 if(ex.length>60)return;ex+=ins;draw()});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&window.AHOSM)window.AHOSM.hide()});
draw();
})();
