// AHOS messenger (hidden inside the calculator). Firebase REST + end-to-end encryption in the browser.
(()=>{
'use strict';
const C=window.AHOS_CFG||{},K=C.apiKey,PR=C.projectId,$=(s,r=document)=>r.querySelector(s),root=$('#app'),calcEl=$('#calc');
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// <crypto>
const S_=crypto.subtle,te=s=>new TextEncoder().encode(s),td=b=>new TextDecoder().decode(b);
const b64=u=>{let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)},ub64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const H=async s=>[...new Uint8Array(await S_.digest('SHA-256',te('ahosmx'+s)))].map(x=>x.toString(16).padStart(2,'0')).join('');
const HC=async s=>[...new Uint8Array(await S_.digest('SHA-256',te('calc:'+s)))].map(x=>x.toString(16).padStart(2,'0')).join('');
const gen=async()=>{const k=await S_.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey']);return{priv:await S_.exportKey('jwk',k.privateKey),pub:await S_.exportKey('jwk',k.publicKey)}};
const shared=async(ek,pub)=>{const pr=await S_.importKey('jwk',ek.priv,{name:'ECDH',namedCurve:'P-256'},false,['deriveKey']),pu=await S_.importKey('jwk',JSON.parse(pub),{name:'ECDH',namedCurve:'P-256'},false,[]);return S_.deriveKey({name:'ECDH',public:pu},pr,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])};
const ce=async(k,by)=>{const iv=crypto.getRandomValues(new Uint8Array(12));return b64(iv)+'.'+b64(new Uint8Array(await S_.encrypt({name:'AES-GCM',iv},k,by)))};
const cd=async(k,s)=>{const[i,c]=s.split('.');return new Uint8Array(await S_.decrypt({name:'AES-GCM',iv:ub64(i)},k,ub64(c)))};
// </crypto>
const M={},L={get(k,d){if(k in M)return M[k];try{const v=localStorage.getItem('mx_'+k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){M[k]=v;try{localStorage.setItem('mx_'+k,JSON.stringify(v))}catch(e){}}};
const toast=m=>{const e=$('#toast');e.textContent=m;e.style.opacity=1;clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.opacity=0,2400)};
const PSP=()=>window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.PrivacyScreen,setPS=on=>{const p=PSP();if(p)try{on?p.enable():p.disable()}catch(e){}};
const VER=window.AHOS_VER||{code:0,name:'0',notes:{}},UPD=window.AHOS_UPD||{};
root.style.cssText+=';position:fixed;inset:0;z-index:5;background:var(--bg);flex-direction:column';
const S={scr:'boot',tab:'chats',q:'',msgs:[],menu:0,reply:null,emoji:0,att:0,sheet:null,hv:0,pull:0,stick:0,rec:0,pt:0,view:'',oe:false,own:false,pf:null,x:0};
const A={},SC={};
const api0={open(){root.style.display='flex';calcEl.style.display='none';setPS(true);if(!S.started){S.started=1;init()}else{route()}},close(){root.style.display='none';calcEl.style.display='flex';setPS(false);S.hv=0;S.pull=0;S.sheet=null;S.view='';if(S.scr=='chat'||S.scr=='nw'||S.scr=='owner')S.scr='main'},hide(){S.hat=Date.now()}};
window.AHOSM=api0;
if(!K||/^PUT_/.test(K)){api0.open=()=>{root.style.display='flex';calcEl.style.display='none';root.innerHTML='<div class=ct><div class=logo>⚙️</div><p>مفاتيح Firebase ناقصة: ضيفها في الأسرار على GitHub (AHOS_CONFIG_JS).</p><button class="btn g" data-a=lock>رجوع</button></div>'};A.lock=()=>api0.close();document.addEventListener('click',e=>{const b=e.target.closest('[data-a=lock]');if(b)A.lock()});return}

// ---------- Firebase REST ----------
const FS=`https://firestore.googleapis.com/v1/projects/${PR}/databases/(default)/documents`,ID='https://identitytoolkit.googleapis.com/v1/accounts:',DB=`projects/${PR}/databases/(default)/documents`;
let AU=L.get('au',null);
const post=async(u,b)=>{const r=await fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}),j=await r.json();if(!r.ok)throw j.error||j;return j};
const save=j=>{AU={r:j.refreshToken||j.refresh_token,u:j.localId||j.user_id,id:j.idToken||j.id_token,e:Date.now()+(+(j.expiresIn||j.expires_in)-60)*1e3};L.set('au',AU)};
const tok=async()=>{if(AU&&AU.e>Date.now())return AU.id;if(AU&&AU.r){try{const r=await fetch('https://securetoken.googleapis.com/v1/token?key='+K,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=refresh_token&refresh_token='+AU.r}),j=await r.json();if(r.ok){save(j);return AU.id}}catch(e){}}throw{message:'AUTH'}};
const fs=async(m,p,b)=>{const r=await fetch(FS+p,{method:m,headers:{Authorization:'Bearer '+await tok(),'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined});if(r.status==404)return null;const j=await r.json();if(!r.ok)throw j.error||j;return j};
const enc=o=>({fields:Object.fromEntries(Object.entries(o).map(([k,v])=>[k,typeof v=='number'?{doubleValue:v}:{stringValue:String(v)}]))});
const dec=d=>Object.fromEntries(Object.entries(d.fields||{}).map(([k,v])=>[k,v.doubleValue!==undefined?+v.doubleValue:v.integerValue!==undefined?+v.integerValue:v.stringValue]));
const patch=(p,o,mask)=>fs('PATCH',p+(mask?'?'+mask.map(k=>'updateMask.fieldPaths='+k).join('&'):''),enc(o));
const list=async p=>{const j=await fs('GET',p);return((j&&j.documents)||[]).map(d=>({...dec(d),_i:d.name.split('/').pop()}))};

// ---------- helpers ----------
const hue=s=>{let h=0;for(const c of String(s||'?'))h=(h*31+c.charCodeAt(0))%360;return h};
const av=(n,a,sz=50)=>`<div class=av style="width:${sz}px;height:${sz}px;font-size:${Math.round(sz*.4)}px;${a?`background-image:url('${a}')`:`background:linear-gradient(135deg,hsl(${hue(n)} 70% 45%),hsl(${(hue(n)+50)%360} 70% 35%))`}">${a?'':esc((String(n||'?').trim()[0]||'?')).toUpperCase()}</div>`;
const hm=ms=>new Date(ms).toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'});
const dayOf=ms=>{const d=new Date(ms),n=new Date(),y=new Date(Date.now()-864e5);return d.toDateString()==n.toDateString()?'النهاردة':d.toDateString()==y.toDateString()?'امبارح':d.toLocaleDateString('ar-EG',{day:'numeric',month:'long'})};
const fz=n=>n>1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB',dur=s=>Math.floor((s||0)/60)+':'+String(Math.round((s||0)%60)).padStart(2,'0');
const stars=m=>{if(m.pend)return '<span class=m>🕓</span>';let s=m.st||0;if(!L.get('rr',1)&&s>1)s=1;return `<span class="stz ${s>1?'sn':''}">★${s>=1?'★':''}</span>`};
const cidOf=u=>[AU.u,u].sort().join('_');
const ring=()=>{if(L.get('snd',1)==0)return;try{navigator.vibrate&&navigator.vibrate([100,50,100]);const c=new(window.AudioContext||window.webkitAudioContext)();[880,1175].forEach((f,i)=>{const o=c.createOscillator(),g=c.createGain(),t0=c.currentTime+i*.16;o.frequency.value=f;o.connect(g);g.connect(c.destination);g.gain.setValueAtTime(.15,t0);g.gain.exponentialRampToValueAtTime(.001,t0+.35);o.start(t0);o.stop(t0+.4)})}catch(e){}};
const LNP=()=>window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.LocalNotifications;
const notifyOS=async()=>{const ln=LNP();if(ln){try{await ln.schedule({notifications:[{id:Date.now()%2147483000,title:'AHOS',body:'1',channelId:'calc'}]})}catch(e){}}else if(window.Notification&&Notification.permission=='granted')try{new Notification('AHOS',{body:'1'})}catch(e){}};
const askNotif=async()=>{const ln=LNP();if(ln){try{await ln.requestPermissions();await ln.createChannel({id:'calc',name:'AHOS',importance:4,vibration:true})}catch(e){}}else if(window.Notification&&Notification.permission=='default')try{await Notification.requestPermission()}catch(e){}};

// ---------- conversations & messages ----------
const SK={},MB={},AUD={};let PL=0;
const kf=async c=>{const ek=L.get('ek');if(!ek)throw new Error('no key');return SK[c.uid+c.k]||(SK[c.uid+c.k]=await shared(ek,c.k))};
const conv=u=>L.get('cv',{})[u],setConv=(u,o)=>{const c=L.get('cv',{});c[u]={...(c[u]||{}),...o};L.set('cv',c)};
const fetchM=async cid=>(await list('/mx_msg/'+cid+'/m?orderBy=id%20desc&pageSize=60')).reverse();
const openMsgs=async(c,docs)=>{const k=await kf(c);return Promise.all(docs.map(async m=>{if(m.de)return{...m,del:1};try{return{...m,p:JSON.parse(td(await cd(k,m.c)))}}catch(e){return{...m,old:1}}}))};
const prev=m=>m.del?'🚫 اتحذفت':m.old?'🔒':m.p.t!==undefined?m.p.t:m.p.k=='a'?'🎙 رسالة صوتية':m.p.k=='i'?'🖼️ صورة':m.p.k=='v'?'🎬 فيديو':'📎 '+(m.p.nm||'ملف');
const ping=u=>{if(u!=AU.u)patch('/mx_inbox/'+u,{[AU.u]:Date.now()},[AU.u]).catch(()=>{})};
const mark=(cid,docs,to,other)=>{let n=0;for(const m of docs)if(m.f!==AU.u&&m.st<to&&!m.de){n++;patch('/mx_msg/'+cid+'/m/'+m._i,{st:to},['st']).catch(()=>{})}if(n)ping(other)};
const visible=m=>{const clr=(L.get('clr',{})[S.peer?S.peer.uid:'']||0);return!(L.get('hidm',[]).includes(m.id)||m.id<=clr||(m.ex&&m.ex<Date.now()))};
const sync=async(u,notify)=>{let c=conv(u);if(!c||!c.k){const d=await fs('GET','/mx_dir/i_'+u);if(!d)return;const f=dec(d);setConv(u,{uid:u,n:f.n,k:f.k,a:f.a||'',uname:f.un||''});c=conv(u)}
const cid=cidOf(u),docs=await fetchM(cid),list_=await openMsgs(c,docs),cur=S.scr=='chat'&&S.peer&&S.peer.uid==u&&!document.hidden&&root.style.display!='none',fresh=docs.filter(m=>m.f!==AU.u&&m.st==0&&!m.de).length;
if(S.scr=='chat'&&S.peer&&S.peer.uid==u){S.msgs=list_;if(cur)S.stick=1}
L.set('m_'+cid,list_.slice(-40));
if(u!=AU.u)mark(cid,docs,cur&&L.get('rr',1)?2:1,u);
const last=list_[list_.length-1],ls=(L.get('lsn',{})[u])||0;
setConv(u,{last:last?prev(last):'',lf:last?last.f:'',lst:last?last.st:0,ts:last?last.id:((conv(u)||{}).ts||Date.now()),un:cur?0:list_.filter(m=>m.f!==AU.u&&m.id>ls&&!m.del).length});
if(cur){const l=L.get('lsn',{});l[u]=Date.now();L.set('lsn',l)}
else if(notify&&fresh&&!(conv(u)||{}).mute){ring();notifyOS()}
R()};
let busy=0;
const poll=async()=>{if(busy||!AU||!['main','chat','nw','owner'].includes(S.scr))return;busy=1;try{const d=await fs('GET','/mx_inbox/'+AU.u);if(d){const f=dec(d),ib=L.get('ib',{}),first=!L.get('ibf',0);for(const u in f){if(u.length>28){incoming(u.slice(1),f[u]);continue}if(f[u]<=(ib[u]||0))continue;ib[u]=f[u];await sync(u,!first)}L.set('ib',ib);L.set('ibf',1)}}catch(e){}finally{busy=0}};
const pres=()=>{if(AU&&S.pf&&!document.hidden&&L.get('pv',1)&&root.style.display!='none')patch('/mx_pres/'+AU.u,{t:Date.now()}).catch(()=>{})};
const peerPres=async()=>{if(S.scr!='chat'||!S.peer||S.peer.uid==AU.u)return;try{const d=await fs('GET','/mx_pres/'+S.peer.uid);S.pt=d?dec(d).t:0;const e=$('#pst');if(e)e.textContent=pst()}catch(e){}};
const pst=()=>S.peer&&S.peer.saved?'مساحتك الخاصة':S.pt&&Date.now()-S.pt<75000?'متصل الآن':S.pt?'آخر ظهور '+hm(S.pt):'مشفّرة 🔒';

// ---------- media ----------
const putBlob=async(cid,id,u8)=>{const s=b64(u8),n=Math.ceil(s.length/700000);for(let i=0;i<n;i++)await patch('/mx_msg/'+cid+'/b/'+id+'_'+i,{d:s.slice(i*700000,(i+1)*700000)});return n};
const getBlob=async(cid,id,n)=>{const parts=await Promise.all(Array.from({length:n},(_,i)=>fs('GET','/mx_msg/'+cid+'/b/'+id+'_'+i).then(d=>dec(d).d)));return Uint8Array.from(atob(parts.join('')),c=>c.charCodeAt(0))};
const prep=async(f,max=1600)=>{const bm=await createImageBitmap(f),r=Math.min(1,max/Math.max(bm.width,bm.height)),c=document.createElement('canvas');c.width=Math.round(bm.width*r);c.height=Math.round(bm.height*r);c.getContext('2d').drawImage(bm,0,0,c.width,c.height);const blob=await new Promise(o=>c.toBlob(o,'image/jpeg',.82)),t=document.createElement('canvas'),q=32/Math.max(c.width,c.height);t.width=Math.max(1,Math.round(c.width*q));t.height=Math.max(1,Math.round(c.height*q));t.getContext('2d').drawImage(c,0,0,t.width,t.height);return{blob,th:t.toDataURL('image/jpeg',.5),w:c.width,h:c.height}};
const loadMedia=async m=>{if(MB[m.id])return MB[m.id];const p=m.p,u8=await getBlob(cidOf(S.peer.uid),p.b,p.n),k=await S_.importKey('raw',ub64(p.fk),'AES-GCM',false,['decrypt']),pt=await S_.decrypt({name:'AES-GCM',iv:ub64(p.iv)},k,u8);return MB[m.id]=URL.createObjectURL(new Blob([pt],{type:p.m||'application/octet-stream'}))};
const hydrate=()=>{document.querySelectorAll('[data-mid]').forEach(el=>{const m=S.msgs.find(x=>x.id==el.dataset.mid);if(m&&m.p&&m.p.k=='i'&&!el.dataset.go){el.dataset.go=1;loadMedia(m).then(u=>{el.outerHTML=`<img class=im src="${u}" data-a=iv>`}).catch(()=>{el.textContent='⚠'})}})};
const send=async(p,c0)=>{const c=c0||S.peer;if(!c)return;const id=Date.now(),same=!c0;try{if(same&&S.reply){p.r={i:S.reply.id,t:S.reply.t,n:S.reply.n};S.reply=null}const ttl=(L.get('ttl',{})[c.uid]||0),body={id,f:AU.u,c:await ce(await kf(c),te(JSON.stringify(p))),st:0,de:0,ed:0,rx:''};if(ttl)body.ex=id+ttl;
if(same){S.msgs.push({...body,p,pend:1});S.stick=1;R()}await patch('/mx_msg/'+cidOf(c.uid)+'/m/'+id,body);ping(c.uid);await sync(c.uid,false)}catch(e){S.msgs=S.msgs.filter(m=>m.id!=id);R();toast('❌ '+(e.message||e))}};
const sendFile=async(blob,name,k,extra={})=>{if(blob.size>9e6)return toast('الحد الأقصى 9 ميجا للملف');toast('⬆ …');try{const fk=await S_.generateKey({name:'AES-GCM',length:256},true,['encrypt']),iv=crypto.getRandomValues(new Uint8Array(12)),ct=new Uint8Array(await S_.encrypt({name:'AES-GCM',iv},fk,await blob.arrayBuffer())),id=Date.now(),n=await putBlob(cidOf(S.peer.uid),id,ct);await send({k,b:id,n,fk:b64(new Uint8Array(await S_.exportKey('raw',fk))),iv:b64(iv),m:blob.type,nm:name,z:blob.size,...extra})}catch(e){toast('❌ '+(e.message||e))}};

// ---------- screens ----------
const R=()=>{const d=$('#mt'),dv=d?d.value:null,df=d&&document.activeElement===d,q=$('#sq'),qv=q?q.value:null,qf=q&&document.activeElement===q,box=$('#msgs'),atb=!box||box.scrollHeight-box.scrollTop-box.clientHeight<140;
root.innerHTML=(SC[S.scr]||(()=>''))();
const n=$('#mt');if(n){if(dv!==null&&!S.nc)n.value=dv;S.nc=0;if(df)n.focus();n.oninput=()=>{const e=n.value.trim()!=='',a=$('#sb'),b=$('#mc');if(a)a.style.display=e?'':'none';if(b)b.style.display=e?'none':''}}
const sq=$('#sq');if(sq&&qv!==null){sq.value=qv;if(qf){sq.focus();try{sq.setSelectionRange(qv.length,qv.length)}catch(e){}}}
const b=$('#msgs');if(b){if(S.stick||atb)b.scrollTop=b.scrollHeight;S.stick=0;b.onscroll=()=>{const d=$('#sdn');if(d)d.style.display=b.scrollHeight-b.scrollTop-b.clientHeight>220?'grid':'none'}}
hydrate()};
const nav=()=>`<div class=nav>${[['chats','💬','المحادثات'],['calls','📞','المكالمات'],['set','⚙️','الإعدادات']].map(x=>`<button class="${S.tab==x[0]?'on':''}" data-a=tab data-t=${x[0]}><i>${x[1]}</i>${x[2]}</button>`).join('')}</div>`;
const top=(t,l,r)=>`<div class=top>${l||''}<h1>${t}</h1>${r||''}</div>`;
SC.boot=()=>`<div class=ct><div class=logo>★★</div><p class=m>…</p></div>`;
SC.auth=()=>`<div class=ct><div class=logo>★★</div><h1 style="font-size:30px">AHOS</h1><p class=m>مراسلة خاصة ومشفّرة</p><div class=card><input id=em type=email dir=ltr placeholder="الإيميل" autocapitalize=off><input id=pw type=password dir=ltr placeholder="الباسورد (6 على الأقل)"><div class=err id=msg></div><button class=btn data-a=login>دخول</button><button class="btn g" data-a=reg>إنشاء حساب جديد</button><button class=lnk data-a=forgot>نسيت الباسورد؟</button></div><button class=lnk data-a=lock>🧮 رجوع للآلة الحاسبة</button></div>`;
SC.setup=()=>`<div class=ct><div class=logo>👤</div><h2>كمّل بياناتك</h2><div class=card><input id=nm placeholder="الاسم"><input id=un dir=ltr placeholder="اليوزر (a-z 0-9 . _)" autocapitalize=off><input id=ph dir=ltr type=tel placeholder="رقم الموبايل">${S.oe?'':'<div class=m style="margin-bottom:10px">👑 إنت أول حساب: هتبقى المالك وإنت اللي تعمل أكواد الاشتراك.</div>'}<div class=err id=msg></div><button class=btn data-a=psave>حفظ</button></div><button class=lnk data-a=logout>خروج</button></div>`;
SC.redeem=()=>`<div class=ct><div class=logo>🔑</div><h2>كود الاشتراك</h2><p class=m>اكتب الكود اللي اتدّالك من المالك</p><div class=card><input id=code dir=ltr autocapitalize=off autocomplete=off spellcheck=false placeholder="الكود"><div class=err id=msg></div><button class=btn data-a=redeem>تفعيل</button></div><button class=lnk data-a=logout>خروج</button><button class=lnk data-a=lock>🧮 رجوع للآلة الحاسبة</button></div>`;
const sheetH=()=>{const s=S.sheet;if(!s)return'';const t=s.t;let b='';
if(t=='pin')b=`<b>🔒 كلمة سر المحادثات المخفية</b><input id=hp type=password style="margin-top:10px"><div class=err id=smsg></div><button class=btn data-a=hpok>فتح</button>`;
else if(t=='sethp')b=`<b>🔒 اعمل كلمة سر للمحادثات المخفية</b><input id=hp type=password placeholder="4 حروف أو أرقام على الأقل" style="margin-top:10px"><div class=err id=smsg></div><button class=btn data-a=hpset>حفظ</button>`;
else if(t=='calc')b=`<b>🧮 كود فتح التطبيق من الآلة الحاسبة</b><p class=m>أرقام بس (4 لـ 12). بتكتبه في الآلة الحاسبة وتدوس =</p><input id=cc type=tel dir=ltr style="margin-top:10px"><div class=err id=smsg></div><button class=btn data-a=ccset>حفظ</button>`;
else if(t=='cm'){const c=conv(s.u)||{},hid=L.get('hid',[]).includes(s.u),pin=L.get('pin',[]).includes(s.u),tt=(L.get('ttl',{})[s.u]||0);b=`<b>${esc(c.n)}</b><button class=o data-a=cpin>${pin?'📌 إلغاء التثبيت':'📌 تثبيت'}</button><button class=o data-a=chide>${hid?'👁 إظهار المحادثة':'🔒 إخفاء المحادثة'}</button><button class=o data-a=cmute>${c.mute?'🔔 تشغيل الإشعارات':'🔕 كتم'}</button><button class=o data-a=cttl>⏱ رسائل مؤقتة: ${tt?tt/36e5+' ساعة':'مقفولة'}</button><button class=o data-a=cclr>🗑 مسح المحادثة (عندي)</button>`}
else if(t=='att')b=`<button class=o data-a=pf data-w=fi>🖼️ صورة أو فيديو</button><button class=o data-a=pf data-w=fc>📷 كاميرا</button><button class=o data-a=pf data-w=ff>📄 ملف</button>`;
return `<div class=sheet data-a=sx><div data-a=nop>${b}</div></div>`};
const chatsH=()=>{const hid=L.get('hid',[]),pin=L.get('pin',[]),q=S.q.trim().toLowerCase(),hv=S.hv;
let a=Object.values(L.get('cv',{})).filter(c=>c.uid&&(hv?hid.includes(c.uid):!hid.includes(c.uid))&&(!q||(c.n||'').toLowerCase().includes(q)));a.sort((x,y)=>(pin.includes(y.uid)-pin.includes(x.uid))||(y.ts||0)-(x.ts||0));
const rows=a.map(c=>`<div class=li data-a=oc data-u="${esc(c.uid)}" data-lp=1>${av(c.n,c.a)}<div style="flex:1;min-width:0"><div class=nm><span>${pin.includes(c.uid)?'📌 ':''}${esc(c.n)}</span><small class=m>${c.ts?hm(c.ts):''}</small></div><div class=pv>${c.lf===AU.u&&c.last?stars({st:c.lst}):''}<span>${esc(c.last||'')}</span></div></div>${c.un?`<span class=bd>${c.un}</span>`:''}</div>`).join('');
return `${top(hv?'🔒 المخفية':'AHOS',hv?'<button class=ib data-a=hvx>→</button>':'','<button class=ib data-a=lock title="آلة حاسبة">🧮</button>')}<div style="padding:8px 12px 0"><input id=sq placeholder="بحث" autocomplete=off style="margin:0"></div><div class=body id=lst>${S.pull&&!hv?'<div class=li data-a=hvo style="background:var(--p2)"><div class=av style="background:var(--ac)">🔒</div><b>المحادثات المخفية</b></div>':''}${rows||`<div class=ct><p class=m>${hv?'مفيش محادثات مخفية':'ابدأ محادثة بالزرار تحت'}</p></div>`}</div>${hv?'':'<button class=fab data-a=nw>✏️</button>'}${nav()}`};
const tg=(l,k,d)=>`<div class=item data-a=tg data-k=${k}><b>${l}</b><span class="chip ${L.get(k,d)?'on':''}">${L.get(k,d)?'ON':'OFF'}</span></div>`;
const ACC=[['#14b8a6','#8b5cf6'],['#3b82f6','#06b6d4'],['#f97316','#ec4899'],['#22c55e','#14b8a6'],['#a855f7','#ec4899'],['#f43f5e','#f59e0b']];
const setH=()=>{const p=S.pf||{},hm_=L.get('hm','pull');return `${top('الإعدادات')}<div class=body><div class=li><div data-a=avp>${av(p.n,p.a,64)}</div><div style="flex:1;min-width:0"><input id=pn value="${esc(p.n)}" placeholder="الاسم" style="margin-bottom:6px"><input id=pb value="${esc(p.b||'')}" placeholder="الحالة (نبذة عنك)" style="margin:0"></div></div><div style="padding:0 14px"><div class=m>@${esc(p.u)} · ${esc(p.p)}</div><button class="btn s" style="margin-top:8px" data-a=pfsave>حفظ</button></div>
<div class=sec>الإشعارات والخصوصية</div>${tg('صوت الإشعارات','snd',1)}${tg('إيصال القراءة (النجوم السودا)','rr',1)}${tg('إظهار "متصل الآن"','pv',1)}
<div class=sec>المظهر</div><div class=item data-a=th><b>الوضع الداكن / الفاتح</b><span class=m>${L.get('th','dark')=='dark'?'داكن':'فاتح'}</span></div><div class=item><b>اللون</b><div class=row>${ACC.map((c,i)=>`<button class="sw ${L.get('ac',0)==i?'on':''}" data-a=ac data-i=${i} style="background:linear-gradient(135deg,${c[0]},${c[1]})"></button>`).join('')}</div></div><div class=item><b>الخلفية</b><div class=row>${['سادة','نقط','تدرج'].map((n,i)=>`<button class="chip ${L.get('wp',1)==i?'on':''}" data-a=wp data-i=${i}>${n}</button>`).join('')}</div></div>
<div class=sec>المحادثات المخفية</div><div class=item data-a=sethp><b>كلمة سر المحادثات المخفية</b><span class=m>${L.get('hp','')?'متظبطة':'لسه'}</span></div><div class=item><b>طريقة الفتح</b><div class=row><button class="chip ${hm_=='pull'?'on':''}" data-a=hmode data-m=pull>سحب لتحت</button><button class="chip ${hm_=='search'?'on':''}" data-a=hmode data-m=search>كلمة السر في البحث</button></div></div>
<div class=sec>التطبيق</div><div class=item data-a=sccalc><b>كود الآلة الحاسبة</b><span class=m>غيّر</span></div><div class=item data-a=upd><b>التحقق من وجود تحديثات</b><span class=m>v${esc(VER.name)}</span></div>${S.own?'<div class=item data-a=own><b>👑 لوحة المالك (الأكواد والأعضاء)</b><span class=m>›</span></div>':''}<div class=item data-a=logout><b style="color:#f87171">تسجيل الخروج</b></div><div style="height:30px"></div></div>${nav()}`};
SC.main=()=>`${S.sheet?sheetH():''}${S.view?`<div class=pop data-a=ivx><img src="${S.view}"></div>`:''}${S.tab=='chats'?chatsH():S.tab=='calls'?callsH():setH()}`;
SC.nw=()=>`${top('محادثة جديدة','<button class=ib data-a=back>→</button>')}<div class=body><div style="padding:14px"><div class=card><input id=dq dir=ltr placeholder="@اليوزر أو رقم الموبايل" autocapitalize=off><div class=err id=msg></div><button class=btn data-a=dfind>بحث وبدء المحادثة</button></div></div></div>`;
const G={m:'r',d:30,cd:'',len:12,man:'',nu:1,o:{u:1,l:1,n:1,s:1},last:'',codes:[],mem:[]};
const dl=d=>({1:'يوم',7:'أسبوع',30:'شهر',365:'سنة'}[d]||d+' يوم');
SC.owner=()=>`${top('👑 لوحة المالك','<button class=ib data-a=back>→</button>')}<div class=body><div style="padding:14px;display:grid;gap:12px"><div class=card><b>إنشاء كود اشتراك</b><div class=row style="margin:10px 0"><button class="chip ${G.m=='r'?'on':''}" data-a=gm data-m=r>🎲 عشوائي</button><button class="chip ${G.m=='m'?'on':''}" data-a=gm data-m=m>✍️ يدوي</button></div>${G.m=='r'?`<input id=len type=number min=6 max=32 value=${G.len} placeholder="الطول"><div class=row style="flex-wrap:wrap;margin-bottom:10px">${[['u','A-Z'],['l','a-z'],['n','0-9'],['s','#$%']].map(k=>`<button class="chip ${G.o[k[0]]?'on':''}" data-a=go data-k=${k[0]}>${k[1]}</button>`).join('')}</div>`:`<input id=man dir=ltr value="${esc(G.man)}" placeholder="Aa1#xyz" autocapitalize=off>`}<div class=m style="margin-bottom:6px">مدة الاشتراك</div><div class=row style="flex-wrap:wrap;margin-bottom:10px">${[1,7,30,365,'c'].map(d=>`<button class="chip ${G.d==d?'on':''}" data-a=gd data-d=${d}>${d=='c'?'مخصص':dl(d)}</button>`).join('')}</div>${G.d=='c'?`<input id=cd type=number min=1 value="${esc(G.cd)}" placeholder="عدد الأيام">`:''}<div class=m style="margin-bottom:6px">عدد مرات استخدام الكود</div><div class=row style="margin-bottom:10px"><input id=nu type=number min=1 value="${G.nu===0?'':G.nu}" placeholder="∞" style="margin:0"><button class="chip ${G.nu===0?'on':''}" data-a=ginf>∞ بلا نهاية</button></div><button class=btn data-a=ggen>✨ إنشاء الكود</button>${G.last?`<div class=card style="margin-top:6px;text-align:center"><div style="font:800 22px ui-monospace,monospace;direction:ltr">${esc(G.last)}</div><button class="btn s" style="margin-top:8px" data-a=cpy data-c="${esc(G.last)}">نسخ</button></div>`:''}</div>
<div class=card><b>الأكواد (${G.codes.length})</b>${G.codes.map(k=>`<div class=row style="margin-top:10px"><div style="flex:1;min-width:0"><div style="font-family:ui-monospace,monospace;direction:ltr;font-weight:700" data-a=cpy data-c="${esc(k.c)}">${esc(k.c)}</div><div class=m>${dl(k.d)} · <span class=tag>${k.u||0}/${(k.n===undefined?1:k.n)||'∞'}</span></div></div><button class=chip data-a=gdel data-c="${esc(k.c)}">✕</button></div>`).join('')}</div>
<div class=card><b>الأعضاء (${G.mem.length})</b>${G.mem.map(m=>`<div class=row style="margin-top:10px"><div style="flex:1;min-width:0"><b>${esc(m.n)}</b> <span class=m>@${esc(m.u)} · ${esc(m.p)}</span><div class=m>${m.x>Date.now()?'ينتهي '+new Date(m.x).toLocaleDateString('ar-EG'):'مش مشترك'}</div></div>${m.x>Date.now()?`<button class=chip data-a=grv data-u="${esc(m._i)}">إلغاء</button>`:''}</div>`).join('')}</div></div></div>`;
const payH=m=>{const p=m.p||{};if(p.t!==undefined)return `<div>${esc(p.t).replace(/(https?:\/\/[^\s<]+)/g,'<a href="$1" target=_blank rel=noopener style="color:inherit;text-decoration:underline">$1</a>').replace(/\n/g,'<br>')}${p.fw?'<div class=m style="font-size:11px">↪ محوّلة</div>':''}</div>`;
if(p.k=='i')return MB[m.id]?`<img class=im src="${MB[m.id]}" data-a=iv>`:`<div class=im data-mid=${m.id} style="${p.th?`background-image:url('${p.th}');`:''}aspect-ratio:${p.w||4}/${p.h||3}"><span>⏳</span></div>`;
if(p.k=='v')return MB[m.id]?`<video class=im src="${MB[m.id]}" controls playsinline></video>`:`<div class=fl data-a=fo data-i=${m.id}>🎬 فيديو · ${fz(p.z)} ⬇ اضغط للتحميل</div>`;
if(p.k=='a')return `<div class=vm><button data-a=vp data-i=${m.id}>${PL==m.id?'⏸':'▶'}</button><div class=vb><i data-pb=${m.id}></i></div><span>${dur(p.d)}</span></div>`;
return MB[m.id]?`<a class=fl href="${MB[m.id]}" download="${esc(p.nm)}">📄 ${esc(p.nm)} · ${fz(p.z)}</a>`:`<div class=fl data-a=fo data-i=${m.id}>📄 ${esc(p.nm)} · ${fz(p.z)} ⬇</div>`};
const RX=['👍','❤️','😂','😮','😢','🙏'];
const msgH=(m,i,arr)=>{const mine=m.f===AU.u,d=dayOf(m.id),sep=!i||d!=dayOf(arr[i-1].id)?`<div class=sep>${d}</div>`:'';
const body=m.del?'<i class=m>🚫 الرسالة اتحذفت</i>':m.old?'<i class=m>🔒 رسالة قديمة (جهاز تاني)</i>':payH(m),rp=m.p&&m.p.r?`<div class=rq><b>${esc(m.p.r.n)}</b><div>${esc(m.p.r.t)}</div></div>`:'';
const rx=m.rx?`<div class=rxs>${esc(m.rx.split(',').map(x=>x.split(':')[1]).filter(Boolean).join(''))}</div>`:'';
const mk=S.menu==m.id?`<div class=mk>${RX.map(e=>`<button data-a=rx data-i=${m.id} data-e="${e}">${e}</button>`).join('')}<button data-a=rpl data-i=${m.id}>↩ رد</button><button data-a=fwd data-i=${m.id}>↪ تحويل</button>${m.p&&m.p.t!==undefined?`<button data-a=cpt data-i=${m.id}>نسخ</button>`:''}${mine&&m.p&&m.p.t!==undefined&&!m.del?`<button data-a=edt data-i=${m.id}>✏️</button>`:''}<button data-a=dme data-i=${m.id}>🗑 عندي</button>${mine&&!m.del?`<button data-a=dall data-i=${m.id}>🚫 للكل</button>`:''}</div>`:'';
return sep+`<div class="bub ${mine?'me':''}" data-a=mm data-i=${m.id}>${rp}${body}<div class=in>${m.ed&&!m.del?'معدّلة':''}<span>${hm(m.id)}</span>${mine&&!m.del?stars(m):''}</div>${rx}${mk}</div>`};
const EM='😀😂😍🥰😎🤔😢😡👍👎🙏❤️🔥🎉💯✅❌😴🤗😅🙄😬🤝👏💪🌹☕🎁📌⭐'.match(/\p{Extended_Pictographic}\uFE0F?/gu)||[];
SC.chat=()=>{const c=S.peer,q=(S.cq||'').toLowerCase(),vm=S.msgs.filter(visible).filter(m=>!q||(m.p&&m.p.t!==undefined&&String(m.p.t).toLowerCase().includes(q))),wp=['','w1','w2'][L.get('wp',1)];
return `${S.sheet?sheetFull():''}${S.view?`<div class=pop data-a=ivx><img src="${S.view}"></div>`:''}<div class=top><button class=ib data-a=back>→</button><div class=row style="flex:1;min-width:0;gap:10px" data-a=info>${av(c.n,c.a,40)}<div style="min-width:0"><b style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(c.n)}</b><small class=m id=pst>${pst()}</small></div></div>${c.saved?'':'<button class=ib data-a=calla>📞</button><button class=ib data-a=callv>🎥</button>'}<button class=ib data-a=lock>🧮</button></div>
${S.cs?`<div style="padding:6px 12px;background:var(--pn);display:flex;gap:8px;align-items:center"><input id=cqi value="${esc(S.cq||'')}" placeholder="بحث في الرسايل" style="margin:0"><button class=ib data-a=csx>✕</button></div>`:''}
<div class=chat><div class="msgs ${wp}" id=msgs>${vm.length?vm.map(msgH).join(''):`<div class=sep style="margin:auto">${q?'مفيش نتايج':'🔒 الرسايل مشفّرة من طرف لطرف'}</div>`}</div><button class=sdn id=sdn data-a=sdn>↓</button>
${S.reply?`<div class=rbar><div style="flex:1;min-width:0"><b style="color:var(--ac)">${esc(S.reply.n)}</b><div class=m style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(S.reply.t)}</div></div><button class=ib data-a=rplx>✕</button></div>`:''}
${S.emoji?`<div class=emo>${EM.map(e=>`<button data-a=em data-e="${e}">${e}</button>`).join('')}</div>`:''}
<input type=file id=fi hidden accept="image/*,video/*"><input type=file id=fc hidden accept="image/*" capture=environment><input type=file id=ff hidden>
${S.rec?`<div class=cmp><div style="flex:1;color:#ef4444;font-weight:700">🔴 بيسجل… اضغط ■ للإرسال</div><button class="sb rec" data-a=mic>■</button></div>`:`<div class=cmp><button class=ib data-a=emo>😊</button><button class=ib data-a=att>📎</button><input id=mt placeholder="اكتب رسالة" autocomplete=off><button class=sb id=sb data-a=snd style="display:none">➤</button><button class=sb id=mc data-a=mic>🎙</button></div>`}</div>`};

// ---------- actions ----------
document.addEventListener('click',e=>{const b=e.target.closest('#app [data-a]');if(!b)return;if(lpS){lpS=0;return}const f=A[b.dataset.a];if(f)f(b.dataset,b,e)});
let lpT=0,lpS=0;
document.addEventListener('pointerdown',e=>{const el=e.target.closest('#app [data-lp]');if(!el)return;lpS=0;lpT=setTimeout(()=>{lpS=1;S.sheet={t:'cm',u:el.dataset.u};R()},520)});
const lpc=()=>clearTimeout(lpT);['pointerup','pointermove','pointercancel'].forEach(t=>document.addEventListener(t,lpc));
let ty=-1;document.addEventListener('touchstart',e=>{const b=e.target.closest&&e.target.closest('#lst');ty=b&&b.scrollTop==0?e.touches[0].clientY:-1},{passive:true});
document.addEventListener('touchend',e=>{if(ty<0||S.scr!='main'||S.tab!='chats'||S.hv||L.get('hm','pull')!='pull'||!L.get('hp',''))return;if(e.changedTouches[0].clientY-ty>90){S.pull=1;R()}},{passive:true});
document.addEventListener('input',async e=>{const t=e.target;if(t.id=='cqi'){S.cq=t.value;R();const n=$('#cqi');if(n){n.focus();try{n.setSelectionRange(n.value.length,n.value.length)}catch(x){}}return}if(t.id=='sq'){S.q=t.value;if(L.get('hm','pull')=='search'&&L.get('hp','')&&S.q.length>=4&&await H('hp:'+S.q)==L.get('hp','')){S.hv=1;S.q='';t.value='';R();return}R()}});
document.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.id=='mt'&&!e.shiftKey){e.preventDefault();A.snd()}});
document.addEventListener('change',e=>{const t=e.target;if(!['fi','fc','ff','avf'].includes(t.id)||!t.files[0])return;const f=t.files[0];t.value='';
if(t.id=='avf'){setAvatar(f);return}
(async()=>{try{S.sheet=null;if(/^image\//.test(f.type)&&t.id!='ff'){const r=await prep(f);await sendFile(r.blob,'photo.jpg','i',{th:r.th,w:r.w,h:r.h})}else if(/^video\//.test(f.type))await sendFile(f,f.name,'v');else await sendFile(f,f.name,'f')}catch(x){toast('❌ '+(x.message||x))}})()});
document.addEventListener('visibilitychange',()=>{if(document.hidden)S.hat=Date.now();else if(root.style.display!='none'){if(S.hat&&Date.now()-S.hat>20000)api0.close();else if(S.scr=='chat'&&S.peer)sync(S.peer.uid,false).catch(()=>{})}});
const emailOk=e=>/^\S+@\S+\.\S+$/.test(e);
A.lock=()=>api0.close();A.nop=()=>{};A.sx=(d,b,e)=>{if(e.target===b){S.sheet=null;R()}};A.ivx=()=>{S.view='';R()};A.iv=(d,b)=>{S.view=b.src;R()};
A.login=async()=>{const e=$('#msg'),em=$('#em').value.trim(),pw=$('#pw').value;if(!emailOk(em)||pw.length<6)return e.textContent='اكتب إيميل صح وباسورد 6 على الأقل';e.textContent='…';try{save(await post(ID+'signInWithPassword?key='+K,{email:em,password:pw,returnSecureToken:true}));await enter()}catch(x){e.textContent=x instanceof TypeError?'مفيش نت':'الإيميل أو الباسورد غلط'}};
A.reg=async()=>{const e=$('#msg'),em=$('#em').value.trim(),pw=$('#pw').value;if(!emailOk(em)||pw.length<6)return e.textContent='اكتب إيميل صح وباسورد 6 على الأقل';e.textContent='…';try{save(await post(ID+'signUp?key='+K,{email:em,password:pw,returnSecureToken:true}));await enter()}catch(x){e.textContent=x instanceof TypeError?'مفيش نت':(x.message=='EMAIL_EXISTS'?'الإيميل ده عنده حساب: اضغط دخول':'مقدرش ينشئ الحساب: '+(x.message||''))}};
A.forgot=async()=>{const e=$('#msg'),em=$('#em').value.trim();if(!emailOk(em))return e.textContent='اكتب الإيميل الأول';try{await post(ID+'sendOobCode?key='+K,{requestType:'PASSWORD_RESET',email:em});e.textContent='اتبعت رابط الاستعادة على الإيميل'}catch(x){e.textContent='مقدرش يبعت الرابط'}};
A.logout=()=>{['au','pf','own','x','ek','cv','ib','ibf'].forEach(k=>L.set(k,null));AU=null;S.pf=null;S.own=false;S.x=0;S.scr='auth';R()};
A.psave=async()=>{const n=$('#nm').value.trim(),u=$('#un').value.trim().toLowerCase().replace(/^@/,''),p=$('#ph').value.replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\D/g,''),e=$('#msg');if(!n||!/^[a-z0-9._]{3,20}$/.test(u)||p.length<8)return e.textContent='املا الاسم واليوزر (a-z 0-9 . _) ورقم موبايل صحيح';e.textContent='…';
try{const ex=await fs('GET','/mx_dir/u_'+u);if(ex&&dec(ex).uid!==AU.u)return e.textContent='اليوزر ده مستخدم';const ek=L.get('ek')||await gen();L.set('ek',ek);const rec={uid:AU.u,n,un:u,k:JSON.stringify(ek.pub),a:''};
await patch('/mx_profiles/'+AU.u,{n,u,p,b:'',a:'',t:Date.now()});await patch('/mx_dir/u_'+u,rec);await patch('/mx_dir/p_'+p,rec);await patch('/mx_dir/i_'+AU.u,rec);if(!S.oe)await patch('/mx_cfg/owner',{uid:AU.u});await enter()}catch(x){e.textContent=String(x.message||x)}};
A.redeem=async()=>{const c=$('#code').value.trim(),e=$('#msg');if(!c)return;e.textContent='…';try{const id=await H('c:'+c),d=await fs('GET','/mx_codes/'+id);if(!d)return e.textContent='الكود غير صحيح';const k=dec(d),mx=k.n===undefined?1:k.n;if(mx&&k.u>=mx)return e.textContent='الكود ده خلّص استخداماته';const now=Date.now(),x=now+k.d*864e5;
await fs('POST',':commit',{writes:[{update:{name:DB+'/mx_codes/'+id,...enc({u:k.u+1,by:AU.u,at:now})},updateMask:{fieldPaths:['u','by','at']},currentDocument:{updateTime:d.updateTime}},{update:{name:DB+'/mx_users/'+AU.u,...enc({x,cid:id,s:now})}}]});S.x=x;L.set('x',x);route()}catch(x){e.textContent='مقدرش يفعّل الكود (النت أو الكود)'}};
A.tab=d=>{S.tab=d.t;S.sheet=null;R()};A.back=()=>{S.scr='main';S.peer=null;S.sheet=null;S.reply=null;S.emoji=0;R()};
A.nw=()=>{S.scr='nw';R()};
A.dfind=async()=>{const q=$('#dq').value.trim().toLowerCase(),e=$('#msg');if(!q)return;const dg=q.replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[\s+-]/g,''),id=/^\d{8,15}$/.test(dg)?'p_'+dg:'u_'+q.replace(/^@/,'');e.textContent='…';
try{const d=await fs('GET','/mx_dir/'+id);if(!d||dec(d).uid==AU.u)return e.textContent='مش لاقيه';const f=dec(d);setConv(f.uid,{uid:f.uid,n:f.n,k:f.k,a:f.a||'',uname:f.un||'',ts:(conv(f.uid)||{}).ts||Date.now()});A.oc({u:f.uid})}catch(x){e.textContent=String(x.message||x)}};
A.oc=async d=>{const c=conv(d.u);if(!c)return;S.peer=c;S.scr='chat';S.menu=0;S.reply=null;S.emoji=0;S.sheet=null;S.pull=0;S.nc=1;S.pt=0;S.cs=0;S.cq='';S.msgs=L.get('m_'+cidOf(c.uid),[]).filter(m=>!m.pend);S.stick=1;const l=L.get('lsn',{});l[c.uid]=Date.now();L.set('lsn',l);setConv(c.uid,{un:0});askNotif();R();
try{if(!c.saved){const x=await fs('GET','/mx_dir/i_'+c.uid);if(x){const f=dec(x);setConv(c.uid,{n:f.n,k:f.k,a:f.a||'',uname:f.un||''});S.peer=conv(c.uid)}}}catch(e){}sync(c.uid,false).catch(()=>{});peerPres()};
A.snd=async()=>{const i=$('#mt');if(!i)return;const v=i.value.trim();if(!v)return;i.value='';const a=$('#sb'),b=$('#mc');if(a)a.style.display='none';if(b)b.style.display='';await send({t:v})};
A.emo=()=>{S.emoji=S.emoji?0:1;R()};A.em=d=>{const i=$('#mt');if(i){i.value+=d.e;i.oninput&&i.oninput()}};A.att=()=>{S.sheet={t:'att'};R()};A.pf=d=>{const f=$('#'+d.w);if(f)f.click()};
let REC=null,RT=0;
A.mic=async()=>{if(REC){REC.stop();return}try{const s=await navigator.mediaDevices.getUserMedia({audio:true}),ch=[],mr=new MediaRecorder(s);REC=mr;RT=Date.now();mr.ondataavailable=e=>ch.push(e.data);mr.onstop=()=>{s.getTracks().forEach(x=>x.stop());REC=null;S.rec=0;R();sendFile(new Blob(ch,{type:mr.mimeType||'audio/webm'}),'voice.webm','a',{d:Math.round((Date.now()-RT)/1000)})};mr.start();S.rec=1;R()}catch(e){toast('🎙 مفيش صلاحية للمايك')}};
A.mm=(d,b,e)=>{if(e.target.closest('.mk')||e.target.closest('[data-a=iv]')||e.target.closest('[data-a=vp]')||e.target.closest('[data-a=fo]'))return;S.menu=S.menu==d.i?0:+d.i;R()};
const fm=i=>S.msgs.find(m=>m.id==i);
A.vp=async d=>{const m=fm(d.i);if(!m)return;try{if(!AUD[m.id]){const u=await loadMedia(m),a=new Audio(u);a.ontimeupdate=()=>{const b=document.querySelector(`[data-pb="${m.id}"]`);if(b)b.style.width=(a.currentTime/(a.duration||m.p.d||1)*100)+'%'};a.onended=()=>{PL=0;R()};AUD[m.id]=a}if(PL&&PL!=m.id)AUD[PL].pause();if(PL==m.id){AUD[m.id].pause();PL=0}else{AUD[m.id].play();PL=m.id}R()}catch(e){toast('⚠ مقدرش يشغّل')}};
A.fo=async d=>{const m=fm(d.i);if(!m)return;toast('⬇ …');try{await loadMedia(m);R()}catch(e){toast('⚠ مقدرش ينزّل (النت؟)')}};
A.rx=async d=>{const m=fm(d.i);if(!m)return;const cur=(m.rx||'').split(',').filter(Boolean).filter(x=>x.split(':')[0]!=AU.u);if(!((m.rx||'').split(',').includes(AU.u+':'+d.e)))cur.push(AU.u+':'+d.e);m.rx=cur.join(',');S.menu=0;R();try{await patch('/mx_msg/'+cidOf(S.peer.uid)+'/m/'+m._i,{rx:m.rx},['rx']);ping(S.peer.uid)}catch(e){}};
A.rpl=d=>{const m=fm(d.i);if(!m)return;S.reply={id:m.id,t:prev(m).slice(0,80),n:m.f===AU.u?'إنت':S.peer.n};S.menu=0;R();const i=$('#mt');if(i)i.focus()};A.rplx=()=>{S.reply=null;R()};
A.cpt=d=>{const m=fm(d.i);if(m&&m.p)navigator.clipboard&&navigator.clipboard.writeText(m.p.t).then(()=>toast('اتنسخ ✓'),()=>{});S.menu=0;R()};
A.edt=async d=>{const m=fm(d.i);if(!m||!m.p||m.p.t===undefined)return;const n=prompt('تعديل الرسالة',m.p.t);S.menu=0;if(!n||!n.trim())return R();try{const c=await ce(await kf(S.peer),te(JSON.stringify({...m.p,t:n.trim()})));await patch('/mx_msg/'+cidOf(S.peer.uid)+'/m/'+m._i,{c,ed:1},['c','ed']);ping(S.peer.uid);sync(S.peer.uid,false)}catch(e){toast('❌ '+(e.message||e))}};
A.dall=async d=>{const m=fm(d.i);if(!m)return;S.menu=0;try{await patch('/mx_msg/'+cidOf(S.peer.uid)+'/m/'+m._i,{c:'',de:1},['c','de']);ping(S.peer.uid);sync(S.peer.uid,false)}catch(e){toast('❌ '+(e.message||e))}};
A.dme=d=>{const h=L.get('hidm',[]);h.push(+d.i);L.set('hidm',h);S.menu=0;R()};
// hidden chats + chat sheet
const cu=()=>S.sheet&&S.sheet.u;
A.cpin=()=>{const p=L.get('pin',[]),u=cu(),i=p.indexOf(u);i<0?p.push(u):p.splice(i,1);L.set('pin',p);S.sheet=null;R()};
A.cmute=()=>{const c=conv(cu())||{};setConv(cu(),{mute:!c.mute});S.sheet=null;R()};
A.cclr=()=>{const c=L.get('clr',{});c[cu()]=Date.now();L.set('clr',c);setConv(cu(),{last:'',un:0});S.sheet=null;R()};
A.cttl=()=>{const t=L.get('ttl',{}),cur=t[cu()]||0,nx={0:36e5,36e5:864e5,864e5:6048e5,6048e5:0}[cur];t[cu()]=nx===undefined?0:nx;L.set('ttl',t);R()};
A.chide=()=>{const u=cu(),h=L.get('hid',[]),i=h.indexOf(u);if(i>=0){h.splice(i,1);L.set('hid',h);S.sheet=null;R();return}if(!L.get('hp','')){S.sheet={t:'sethp',then:u};R();return}h.push(u);L.set('hid',h);S.sheet=null;toast('اتخبّت 🔒');R()};
A.sethp=()=>{S.sheet={t:'sethp'};R()};
A.hpset=async()=>{const p=$('#hp').value,e=$('#smsg');if(p.length<4)return e.textContent='4 على الأقل';L.set('hp',await H('hp:'+p));const u=S.sheet&&S.sheet.then;if(u){const h=L.get('hid',[]);if(!h.includes(u))h.push(u);L.set('hid',h)}S.sheet=null;toast('اتحفظت ✓');R()};
A.hpok=async()=>{const p=$('#hp').value,e=$('#smsg');if(await H('hp:'+p)!=L.get('hp',''))return e.textContent='كلمة السر غلط';S.sheet=null;S.pull=0;S.hv=1;R()};
A.hvo=()=>{S.sheet={t:'pin'};R()};A.hvx=()=>{S.hv=0;R()};
A.hmode=d=>{L.set('hm',d.m);if(d.m=='search'&&!L.get('hp',''))S.sheet={t:'sethp'};R()};
A.sccalc=()=>{S.sheet={t:'calc'};R()};
A.ccset=async()=>{const c=$('#cc').value.trim(),e=$('#smsg');if(!/^\d{4,12}$/.test(c))return e.textContent='أرقام بس: من 4 لـ 12';localStorage.setItem('c_ch',await HC(c));S.sheet=null;toast('اتغيّر ✓');R()};
// settings
A.tg=d=>{L.set(d.k,L.get(d.k,1)?0:1);R()};A.th=()=>{L.set('th',L.get('th','dark')=='dark'?'light':'dark');theme();R()};A.ac=d=>{L.set('ac',+d.i);theme();R()};A.wp=d=>{L.set('wp',+d.i);R()};
const theme=()=>{const h=document.documentElement,c=ACC[L.get('ac',0)]||ACC[0];h.dataset.theme=L.get('th','dark');h.style.setProperty('--ac',c[0]);h.style.setProperty('--ac2',c[1])};
A.pfsave=async()=>{const n=$('#pn').value.trim(),b=$('#pb').value.trim();if(!n)return toast('اكتب الاسم');try{await patch('/mx_profiles/'+AU.u,{n,b},['n','b']);for(const id of ['u_'+S.pf.u,'p_'+S.pf.p,'i_'+AU.u])await patch('/mx_dir/'+id,{n},['n']);S.pf.n=n;S.pf.b=b;L.set('pf',S.pf);toast('اتحفظ ✓');R()}catch(e){toast('❌ '+(e.message||e))}};
A.avp=()=>{let f=$('#avf');if(!f){f=document.createElement('input');f.type='file';f.accept='image/*';f.id='avf';f.hidden=true;root.appendChild(f)}f.click()};
const setAvatar=async f=>{try{const r=await prep(f,192),a=await new Promise(o=>{const fr=new FileReader();fr.onload=()=>o(fr.result);fr.readAsDataURL(r.blob)});await patch('/mx_profiles/'+AU.u,{a},['a']);for(const id of ['u_'+S.pf.u,'p_'+S.pf.p,'i_'+AU.u])await patch('/mx_dir/'+id,{a},['a']);S.pf.a=a;L.set('pf',S.pf);R()}catch(e){toast('❌ '+(e.message||e))}};
// updates (GitHub Releases)
A.upd=async()=>{if(!UPD.repo||/^PUT/.test(UPD.repo))return toast('إعداد التحديث ناقص');toast('بيتحقق…');try{const r=await fetch(`https://api.github.com/repos/${UPD.repo}/releases/latest`,{headers:{Accept:'application/vnd.github+json'}});if(!r.ok)throw 0;const j=await r.json(),code=parseInt(String(j.tag_name).replace(/\D/g,''))||0,a=(j.assets||[]).find(x=>/\.apk$/i.test(x.name));
if(code>VER.code&&a){S.upd={name:j.name||j.tag_name,body:String(j.body||'').split('\n\n')[0],url:a.browser_download_url,size:a.size};S.sheet={t:'upd'};R()}else toast('إنت على أحدث نسخة ✓')}catch(e){toast('مقدرش يتحقق دلوقتي')}};
A.udl=()=>{if(S.upd)window.open(S.upd.url,'_system')};
A.own=async()=>{S.scr='owner';R();loadOwn()};
// owner panel
const loadOwn=async()=>{try{const[c,p,u]=await Promise.all([list('/mx_codes?pageSize=300'),list('/mx_profiles?pageSize=300'),list('/mx_users?pageSize=300')]);G.codes=c.sort((a,b)=>b.t-a.t);const us=Object.fromEntries(u.map(x=>[x._i,x]));G.mem=p.map(x=>({...x,x:(us[x._i]||{}).x||0}))}catch(e){toast(String(e.message||e))}R()};
const gsync=()=>{const g=i=>$('#'+i);if(g('len'))G.len=+g('len').value||12;if(g('man'))G.man=g('man').value;if(g('cd'))G.cd=g('cd').value;if(g('nu'))G.nu=g('nu').value===''?0:Math.max(1,parseInt(g('nu').value)||1)};
A.gm=d=>{gsync();G.m=d.m;R()};A.go=d=>{gsync();G.o[d.k]=G.o[d.k]?0:1;R()};A.gd=d=>{gsync();G.d=d.d=='c'?'c':+d.d;R()};A.ginf=()=>{gsync();G.nu=0;R()};
A.ggen=async()=>{gsync();let c;if(G.m=='m'){c=G.man.trim();if(c.length<3)return toast('الكود قصير')}else{const ss=[['u','ABCDEFGHJKLMNPQRSTUVWXYZ'],['l','abcdefghijkmnpqrstuvwxyz'],['n','23456789'],['s','#$%&*?+=@!']].filter(x=>G.o[x[0]]).map(x=>x[1]);if(!ss.length)return toast('اختار نوع حروف');
const r=n=>{const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]%n},all=ss.join(''),n=Math.max(6,Math.min(32,G.len),ss.length);let ch=ss.map(s=>s[r(s.length)]);while(ch.length<n)ch.push(all[r(all.length)]);for(let i=ch.length-1;i>0;i--){const j=r(i+1);[ch[i],ch[j]]=[ch[j],ch[i]]}c=ch.join('')}
const d=G.d=='c'?Math.max(1,parseInt(G.cd)||1):G.d;try{await patch('/mx_codes/'+await H('c:'+c),{c,d,t:Date.now(),u:0,n:G.nu});G.last=c;loadOwn()}catch(e){toast('❌ '+(e.message||e))}};
A.gdel=async d=>{try{await fs('DELETE','/mx_codes/'+await H('c:'+d.c));loadOwn()}catch(e){toast('❌')}};
A.grv=async d=>{try{await patch('/mx_users/'+d.u,{x:0,cid:'revoked'});loadOwn()}catch(e){toast('❌')}};
A.cpy=d=>navigator.clipboard&&navigator.clipboard.writeText(d.c).then(()=>toast('اتنسخ ✓'),()=>toast(d.c));

// ---------- calls: voice + video (WebRTC peer-to-peer, signaling through Firestore) ----------
const ICE=()=>{const x=[{urls:['stun:stun.l.google.com:19302','stun:stun1.l.google.com:19302']}];if(C.turn)x.push(C.turn);return x};
let CALL=null,RTI=0;
const callEl=document.createElement('div');callEl.className='call';callEl.style.display='none';document.body.appendChild(callEl);
const ra=document.createElement('audio');ra.autoplay=true;ra.playsInline=true;ra.style.display='none';document.body.appendChild(ra);
const tone=()=>{try{navigator.vibrate&&navigator.vibrate([300,150,300]);const c=new(window.AudioContext||window.webkitAudioContext)();[0,.35].forEach(d=>{const o=c.createOscillator(),g=c.createGain(),t0=c.currentTime+d;o.frequency.value=d?660:880;o.connect(g);g.connect(c.destination);g.gain.setValueAtTime(.2,t0);g.gain.exponentialRampToValueAtTime(.001,t0+.3);o.start(t0);o.stop(t0+.35)})}catch(e){}};
const ringTone=on=>{clearInterval(RTI);if(on){tone();RTI=setInterval(tone,1800)}};
const drawCall=()=>{const c=CALL;if(!c){callEl.style.display='none';callEl.innerHTML='';return}const v=c.k=='v',inc=c.st=='ring'&&c.dir=='in';callEl.style.display='flex';
callEl.innerHTML=`${v&&c.remote?'<video class=rv id=rv autoplay playsinline muted></video>':''}${v&&c.local?'<video class=lv id=lv autoplay playsinline muted></video>':''}<div class=who style="margin-top:40px">${av(c.n,c.a,96)}<h2 style="margin-top:12px">${esc(c.n)}</h2><div id=ct class=m style="color:#cbd5e1">${inc?(v?'مكالمة فيديو واردة…':'مكالمة صوتية واردة…'):c.st=='ring'?'بيتصل…':c.st=='on'?dur(c.sec||0):c.st=='end'?esc(c.msg||''):'بيتوصل…'}</div></div>
<div class=ctl>${inc?`<button class="cb red" data-a=cend>✕</button><button class="cb grn" data-a=cacc>${v?'🎥':'📞'}</button>`:`<button class="cb ${c.mute?'off':''}" data-a=cmu>${c.mute?'🔇':'🎙'}</button>${v?`<button class="cb ${c.cam?'off':''}" data-a=ccam>${c.cam?'📵':'📷'}</button><button class=cb data-a=cflip>🔄</button>`:''}<button class="cb red" data-a=cend>✕</button>`}</div>`;
const rv=$('#rv',callEl),lv=$('#lv',callEl);if(rv&&c.remote)rv.srcObject=c.remote;if(lv&&c.local)lv.srcObject=c.local};
const gather=pc=>new Promise(r=>{if(pc.iceGatheringState=='complete')return r();const t=setTimeout(r,4500);pc.onicegatheringstatechange=()=>{if(pc.iceGatheringState=='complete'){clearTimeout(t);r()}}});
const mkpc=()=>{const pc=new RTCPeerConnection({iceServers:ICE()});pc.ontrack=e=>{if(!CALL)return;CALL.remote=e.streams[0];ra.srcObject=CALL.remote;drawCall()};
pc.onconnectionstatechange=()=>{const c=CALL;if(!c||c.st=='end')return;if(pc.connectionState=='connected'&&c.st!='on'){c.st='on';c.t0=Date.now();ringTone(0);c.timer=setInterval(()=>{c.sec=Math.round((Date.now()-c.t0)/1000);const e=$('#ct');if(e)e.textContent=dur(c.sec)},1000);drawCall()}if(pc.connectionState=='failed')endCall(true,'انقطعت المكالمة (الشبكة)')};return pc};
const watch=()=>{const c=CALL;c.pollT=setInterval(async()=>{if(CALL!==c)return;if(c.st=='ring'&&Date.now()-c.id>45000){endCall(true,c.dir=='in'?'مكالمة فائتة':'مفيش رد');return}
try{const d=await fs('GET','/mx_calls/'+c.id);if(!d||CALL!==c)return;const f=dec(d);if(f.st=='end'||f.st=='rej'){endCall(false,f.st=='rej'?'رفض المكالمة':'انتهت المكالمة');return}if(c.dir=='out'&&f.a&&!c.gotA){c.gotA=1;await c.pc.setRemoteDescription(JSON.parse(f.a))}}catch(e){}},1200)};
const endCall=(notify,msg)=>{const c=CALL;if(!c||c.st=='end')return;c.st='end';clearInterval(c.pollT);clearInterval(c.timer);ringTone(0);try{c.pc&&c.pc.close()}catch(e){}if(c.local)c.local.getTracks().forEach(t=>t.stop());ra.srcObject=null;
const sec=c.t0?Math.round((Date.now()-c.t0)/1000):0;if(notify)patch('/mx_calls/'+c.id,{st:'end'},['st']).catch(()=>{});
const lg=L.get('calls',[]);lg.unshift({uid:c.peer,n:c.n,k:c.k,dir:c.dir,ts:Date.now(),d:sec,ok:sec>0});L.set('calls',lg.slice(0,100));c.msg=msg||'انتهت المكالمة';drawCall();setTimeout(()=>{if(CALL===c){CALL=null;drawCall()}},1000);if(S.tab=='calls')R()};
const startCall=async k=>{if(CALL||!S.peer||S.peer.saved)return;S.sheet=null;const p=S.peer;
try{const local=await navigator.mediaDevices.getUserMedia({audio:true,video:k=='v'?{facingMode:'user'}:false});const c=CALL={id:Date.now(),peer:p.uid,n:p.n,a:p.a,k,dir:'out',st:'ring',local,mute:0,cam:0,sec:0,face:'user'};drawCall();
const pc=c.pc=mkpc();local.getTracks().forEach(t=>pc.addTrack(t,local));await pc.setLocalDescription(await pc.createOffer());await gather(pc);if(CALL!==c){pc.close();return}
await patch('/mx_calls/'+c.id,{id:c.id,f:AU.u,to:p.uid,k,st:'ring',o:JSON.stringify(pc.localDescription),a:'',t:Date.now()});await patch('/mx_inbox/'+p.uid,{['c'+AU.u]:c.id},['c'+AU.u]);ringTone(1);watch()}
catch(e){toast('📵 '+(e.name=='NotAllowedError'?'مفيش صلاحية للمايك أو الكاميرا':(e.message||'مقدرش يبدأ المكالمة')));const c=CALL;if(c){c.st='end';clearInterval(c.pollT);if(c.local)c.local.getTracks().forEach(t=>t.stop());CALL=null;drawCall()}}};
const incoming=async(from,id)=>{const lc=L.get('lc',{});if(id<=(lc[from]||0))return;lc[from]=id;L.set('lc',lc);if(Date.now()-id>45000)return;
try{const d=await fs('GET','/mx_calls/'+id);if(!d)return;const f=dec(d);if(f.st!='ring'||f.to!==AU.u)return;if(CALL){patch('/mx_calls/'+id,{st:'rej'},['st']).catch(()=>{});return}
let c=conv(from);if(!c){const x=await fs('GET','/mx_dir/i_'+from);if(x){const g=dec(x);setConv(from,{uid:from,n:g.n,k:g.k,a:g.a||'',uname:g.un||''});c=conv(from)}}
CALL={id,peer:from,n:c?c.n:'؟',a:c?c.a:'',k:f.k,dir:'in',st:'ring',offer:f.o,mute:0,cam:0,sec:0};drawCall();ringTone(1);notifyOS();watch()}catch(e){}};
A.calla=()=>startCall('a');A.callv=()=>startCall('v');
A.cacc=async()=>{const c=CALL;if(!c||c.dir!='in'||c.st!='ring')return;try{ringTone(0);c.st='conn';const local=await navigator.mediaDevices.getUserMedia({audio:true,video:c.k=='v'?{facingMode:'user'}:false});c.local=local;const pc=c.pc=mkpc();local.getTracks().forEach(t=>pc.addTrack(t,local));await pc.setRemoteDescription(JSON.parse(c.offer));await pc.setLocalDescription(await pc.createAnswer());await gather(pc);await patch('/mx_calls/'+c.id,{a:JSON.stringify(pc.localDescription),st:'acc'},['a','st']);drawCall()}catch(e){toast('📵 '+(e.name=='NotAllowedError'?'مفيش صلاحية للمايك أو الكاميرا':(e.message||'')));endCall(true,'مقدرش يرد')}};
A.cend=()=>{const c=CALL;if(!c)return;endCall(true,c.dir=='in'&&c.st=='ring'?'رفضت المكالمة':'انتهت المكالمة');if(c.dir=='in'&&c.st=='end'&&!c.t0)patch('/mx_calls/'+c.id,{st:'rej'},['st']).catch(()=>{})};
A.cmu=()=>{const c=CALL;if(!c||!c.local)return;c.mute=!c.mute;c.local.getAudioTracks().forEach(t=>t.enabled=!c.mute);drawCall()};
A.ccam=()=>{const c=CALL;if(!c||!c.local)return;c.cam=!c.cam;c.local.getVideoTracks().forEach(t=>t.enabled=!c.cam);drawCall()};
A.cflip=async()=>{const c=CALL;if(!c||!c.pc)return;try{c.face=c.face=='user'?'environment':'user';const ns=await navigator.mediaDevices.getUserMedia({video:{facingMode:c.face}}),nt=ns.getVideoTracks()[0],sd=c.pc.getSenders().find(x=>x.track&&x.track.kind=='video');if(sd)await sd.replaceTrack(nt);c.local.getVideoTracks().forEach(t=>{t.stop();c.local.removeTrack(t)});c.local.addTrack(nt);drawCall()}catch(e){toast('📷 ✖')}};
const callsH=()=>`${top('المكالمات')}<div class=body>${L.get('calls',[]).map(c=>`<div class=li data-a=cb data-u="${esc(c.uid)}" data-k=${c.k}>${av(c.n,(conv(c.uid)||{}).a)}<div style="flex:1;min-width:0"><div class=nm><span style="${!c.ok&&c.dir=='in'?'color:#f87171':''}">${esc(c.n)}</span></div><div class=pv>${c.dir=='in'?(c.ok?'↙':'↙ فائتة'):'↗'} ${c.k=='v'?'🎥':'📞'} ${new Date(c.ts).toLocaleString('ar-EG',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}${c.ok?' · '+dur(c.d):''}</div></div><span class=ib>${c.k=='v'?'🎥':'📞'}</span></div>`).join('')||'<div class=ct><p class=m>مفيش مكالمات لسه<br>ابدأ مكالمة من جوه أي محادثة</p></div>'}</div>${nav()}`;
A.cb=d=>{const c=conv(d.u);if(!c)return;S.peer=c;startCall(d.k)};
// ---------- chat info, search, forward ----------
const infoH=()=>{const c=S.peer||{},tt=(L.get('ttl',{})[c.uid]||0);return `<div class=sheet data-a=sx><div data-a=nop><div style="text-align:center">${av(c.n,c.a,96)}<h2 style="margin-top:8px">${esc(c.n)}</h2><div class=m>${c.uname?'@'+esc(c.uname):''}</div></div>${c.saved?'':'<div class=row style="justify-content:center;gap:12px;margin:14px 0"><button class=chip data-a=calla>📞 صوتي</button><button class=chip data-a=callv>🎥 فيديو</button><button class=chip data-a=cs>🔍 بحث</button></div>'}<button class=o data-a=cttl>⏱ رسائل مؤقتة: ${tt?tt/36e5+' ساعة':'مقفولة'}</button><button class=o data-a=cmute>${c.mute?'🔔 تشغيل الإشعارات':'🔕 كتم الإشعارات'}</button><button class=o data-a=cclr>🗑 مسح المحادثة (عندي)</button></div></div>`};
const fwdH=()=>`<div class=sheet data-a=sx><div data-a=nop><b>↪ تحويل إلى…</b>${Object.values(L.get('cv',{})).filter(c=>c.uid&&!L.get('hid',[]).includes(c.uid)).map(c=>`<button class=o data-a=fwdto data-u="${esc(c.uid)}">${esc(c.n)}</button>`).join('')}</div></div>`;
A.info=()=>{if(S.peer){S.sheet={t:'info',u:S.peer.uid};R()}};A.cs=()=>{S.cs=1;S.sheet=null;R()};A.csx=()=>{S.cs=0;S.cq='';R()};A.sdn=()=>{const b=$('#msgs');if(b)b.scrollTop=b.scrollHeight};
A.fwd=d=>{S.sheet={t:'fwd',m:+d.i};S.menu=0;R()};
A.fwdto=async d=>{const m=fm(S.sheet.m),c=conv(d.u);S.sheet=null;if(m&&m.p&&m.p.t!==undefined&&c){await send({t:m.p.t,fw:1},c);toast('اتحوّلت ✓')}else toast('تحويل النص بس');R()};

// ---------- start ----------
const GATE=['boot','auth','setup','redeem'];
const enter=async()=>{try{const[ow,pf,us]=await Promise.all([fs('GET','/mx_cfg/owner'),fs('GET','/mx_profiles/'+AU.u),fs('GET','/mx_users/'+AU.u)]);S.oe=!!ow;S.own=!!(ow&&dec(ow).uid==AU.u);S.pf=pf?dec(pf):null;const u=us&&dec(us);S.x=u&&u.x>Date.now()?u.x:0;L.set('pf',S.pf);L.set('own',S.own);L.set('x',S.x);L.set('oe',S.oe)}catch(e){S.pf=L.get('pf',null);S.own=L.get('own',false);S.x=L.get('x',0);S.oe=L.get('oe',false)}route()};
let started=0;
const route=()=>{const g=!AU?'auth':!S.pf?'setup':(!S.own&&Date.now()>S.x)?'redeem':'';if(g)S.scr=g;else if(GATE.includes(S.scr))S.scr='main';R();if(!g)start()};
const start=async()=>{if(started)return;started=1;try{if(!L.get('ek')){const ek=await gen();L.set('ek',ek);const rec=JSON.stringify(ek.pub);for(const id of ['u_'+S.pf.u,'p_'+S.pf.p,'i_'+AU.u])await patch('/mx_dir/'+id,{k:rec},['k']).catch(()=>{});toast('جهاز جديد: الرسايل القديمة مش هتظهر')}
if(!conv(AU.u))setConv(AU.u,{uid:AU.u,n:'الرسائل المحفوظة',k:JSON.stringify(L.get('ek').pub),saved:1,ts:Date.now()})}catch(e){}
setInterval(poll,4000);setInterval(pres,45000);setInterval(peerPres,15000);setTimeout(poll,800);pres();askNotif();R();
const lv=L.get('lv',0);if(lv&&lv<VER.code){const n=(VER.notes&&VER.notes.ar)||[];S.sheet={t:'new',n};R()}L.set('lv',VER.code)};
// extra sheets (update + what's new)
const _sh=sheetH;
const sheetFull=()=>{const s=S.sheet;if(s&&s.t=='info')return infoH();if(s&&s.t=='fwd')return fwdH();if(s&&s.t=='upd'){const u=S.upd;return `<div class=sheet data-a=sx><div data-a=nop><b>🆕 فيه تحديث: ${esc(u.name)}</b><div class=m style="margin:8px 0;white-space:pre-wrap">${esc(u.body)}</div><div class=m style="margin-bottom:10px">بعد التحميل افتح الملف واضغط تثبيت.</div><button class=btn data-a=udl>⬇ تحميل (${(u.size/1048576).toFixed(1)} MB)</button></div></div>`}
 if(s&&s.t=='new')return `<div class=sheet data-a=sx><div data-a=nop><b>🎉 اللي اتضاف في التحديث</b><div style="margin:10px 0;white-space:pre-wrap">${esc((s.n||[]).map(x=>'• '+x).join('\n'))}</div><button class=btn data-a=sx>تمام</button></div></div>`;return _sh()};
const init=()=>{theme();if(!AU){S.scr='auth';R();return}S.scr='boot';R();enter()};
SC.main=()=>`${S.sheet?sheetFull():''}${S.view?`<div class=pop data-a=ivx><img src="${S.view}"></div>`:''}${S.tab=='chats'?chatsH():S.tab=='calls'?callsH():setH()}`;
window.AHOSM._t={S,SC,A,L,R,setAU:v=>{AU=v},sheetFull,callUI:c=>{CALL=c;drawCall();const h=callEl.innerHTML;CALL=null;drawCall();return h}};
})();
